package calculations;

public class DiamterValues {

    private double ideald;
    private double idealPrevious;
    private double idealNext;

    public double getIdeald() {
        return ideald;
    }

    public void setIdeald(double ideald) {
        this.ideald = ideald;
    }

    public double getIdealPrevious() {
        return idealPrevious;
    }

    public void setIdealPrevious(double idealPrevious) {
        this.idealPrevious = idealPrevious;
    }

    public double getIdealNext() {
        return idealNext;
    }

    public void setIdealNext(double idealNext) {
        this.idealNext = idealNext;
    }
}
