package calculations;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import java.text.DecimalFormat;


/**
 * Created by User on 14/3/2017.
 */
@Path("/calculator")
public class Calculator {

    private static final double[] dList = {0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.40, 1.60};

    @GET
    @Path("/diameter")
    @Produces("application/json")
    public DiameterValues diameter(@QueryParam("Qin") double Qin,
                                   @QueryParam("din") double din,
                                   @QueryParam("tin") double tin,
                                   @QueryParam("roughness") double roughness,
                                   @QueryParam("angle") double angle) {

        double d = 0;
        if (din == 0) {
            d = tin / 0.9382;
        } else {

            d = computeD(Qin, din, roughness, angle);
        }

        double ideald = 0;
        double idealPrevious = 0;
        double idealNext = 0;

        for (int i = 1; i < dList.length; i++) {
            if (dList[i] >= d) {
                ideald = dList[i];
                if (i > 0) {
                    idealPrevious = dList[i - 1];
                } else {
                    idealPrevious = dList[i];
                }
                if (i < dList.length - 1) {
                    idealNext = dList[i + 1];
                } else {
                    idealNext = dList[i];
                }
                break;
            }
        }
        if (d < dList[0]) {
            ideald = dList[0];
            idealNext = dList[1];
        } else if (ideald == 0) {
            ideald = dList[dList.length - 1];
            idealPrevious = dList[dList.length - 2];
        }
        DiameterValues values = new DiameterValues();
        values.setIdeald(ideald);
        values.setIdealNext(idealNext);
        values.setIdealPrevious(idealPrevious);

        return values;
    }

    public static double computeD(double Qin, double din, double roughness, double angle) {
        double tin = 0.9382 * din;
        double b = computeB(din, tin);
        double surface = computeA(din, b);
        double R = R(surface, b, din);
        double Qmax = qin(R, roughness, angle, surface);


        if (Qin <= Qmax) {

            if (din < 0.1) {
                din = 0.1;
            }

            return din;
        } else {

            while (Qin > Qmax) {
                din = din + 0.01 * din;
                b = computeB(din, tin);
                surface = computeA(din, b);
                R = R(surface, b, din);
                Qmax = qin(R, roughness, angle, surface);
            }
        }

        if (din < 0.1) {
            din = 0.1;
        }
        return din;
    }


    @GET
    @Path("/allValues")
    @Produces("application/json")
    public CalculationValues calculations(
            @QueryParam("Qin") double Qin,
            @QueryParam("tin") double tin,
            @QueryParam("roughness") double roughness,
            @QueryParam("angle") double angle,
            @QueryParam("diameter") double dFinal

    ) {

        CalculationValues calculationValues = new CalculationValues();
        double idealt = 0;
        if (tin == 0) {
            idealt = computeT(dFinal, roughness, angle, Qin);
        } else {
            idealt = tin;
        }
        double b = computeB(dFinal, idealt);
        double surface = computeA(dFinal, b);
        double R = R(surface, b, dFinal);
        double qin = 0;
        if (Qin == 0) {
            qin = qin(R, roughness, angle, surface);
        } else {
            qin = Qin;
        }
        DecimalFormat df = new DecimalFormat("#0.####");

        calculationValues.setAngle(df.format(angle));
        calculationValues.setRoughness(df.format(roughness));
        calculationValues.setQin(df.format(qin));
        calculationValues.setTin(df.format(idealt));
        calculationValues.setIdealt(df.format(idealt));

        double speed = speed(qin, surface);
        calculationValues.setSpeed(df.format(speed));
        calculationValues.setSurface(String.format("%.12f", surface));

        double width = width(dFinal, idealt);
        calculationValues.setWidth(df.format(width));
        calculationValues.setEnergy(df.format(energy(speed)));
        calculationValues.setFroud(df.format(froud(surface, width, speed)));

        return calculationValues;
    }


    //ideal depth calculation
    public static double computeT(double dFinal, double roughness, double angle, double Qin) {

        double tInit = 0.9382 * (dFinal / 2);
        double b = computeB(dFinal, tInit);
        double surface = computeA(dFinal, b);
        double R = R(surface, b, dFinal);
        double Qcalc = qin(R, roughness, angle, surface);
        double tcalc = tInit;
        if (Qcalc >= (Qin - ((0.01 / 100) * dFinal)) && Qcalc <= (((0.01 / 100) * dFinal) + Qin)) {
            return tInit;

        } else {
            System.out.println(Qin - ((0.01 / 100) * dFinal));
            System.out.println((((0.01 / 100) * dFinal) + Qin));
            int step = 1;

            while (!(Qcalc >= (Qin - ((0.01 / 100)*  dFinal)) && Qcalc <= (((0.01 / 100)*  dFinal) + Qin))){
                if (Qcalc >= (Qin + ((0.01 / 100) * dFinal))) {

                    if (step != 1) {
                        tcalc = tcalc - tInit / step;
                    }
                } else {

                    if (step != 1) {
                        tcalc = tcalc + tInit / step;
                    }
                }
                b = computeB(dFinal, tcalc);
                surface = computeA(dFinal, b);
                R = R(surface, b, dFinal);
                Qcalc = qin(R, roughness, angle, surface);
                step = step * 2;
            }

        }
        return tcalc;
    }


    //b calculation
    public static double computeB(double dFinal, double idealt) {
        double radius = dFinal / 2;
        double v = ((radius - idealt) / radius);
        double f = Math.acos(v);
        return 2 * f;
    }


    //surface calculation
    public static double computeA(double dFinal, double b) {
        double radius = dFinal / 2;
        return (Math.pow(radius, 2) / 2) * (b - Math.sin(b));
    }


    //Q=Qin calculation
    public static double qin(double R, double roughness, double angle, double surface) {

        return (1 / roughness) * Math.pow(R, (double) 2 / 3) * surface * Math.pow(angle, (double) 1 / 2);
    }


    //speed calculation
    public static double speed(double qin, double surface) {
        return qin / surface;
    }


    //width calculation
    public static double width(double dFinal, double t) {
        double c = t * (dFinal - t);
        return 2 * Math.sqrt(c);
    }


    //energy calculation
    public static double energy(double speed) {
        return Math.pow(speed, 2) / (2 * 9.81);
    }


    //froud calculation
    public static double froud(double a, double B, double speed) {
        double th = a / B;
        return speed / (Math.sqrt(9.81 * th));
    }


    //R(υδραυλική ακτίνα) calculation
    public static double R(double surface, double b, double dFinal) {
        double R = surface / ((dFinal / 2) * b);
        return R;
    }

}






