var host = window.location.protocol + "//" + window.location.host;
/**
 * selects the dom element with the given id and
 * updates its content with the input
 * @param elementId
 * @param value
 */
function updateElementWithValue(elementId, value) {
    var element = document.getElementById(elementId);
    element.innerHTML = value;
}

/**
 * closes the pop up window
 */

function closePopUp() {
    var confirmationModal = document.getElementById('confModal');
    confirmationModal.style.display = "none";
}

/**
 * makes a rest call to the back end in order to compute the diameter,
 * and displays the response to the user.
 * @param d
 */

function computeDiameter(Qin, tin, angle, roughness, din) {
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == XMLHttpRequest.DONE) {
            if (xmlhttp.status == 200) {
                //get the object from the response
                var obj = JSON.parse(xmlhttp.responseText);

                // create modal content and display it
                var confirmationModal = document.getElementById('confModal');
                var value = '<ul><li>ιδανική διάμετρος εμπορίου = ' + obj['ideald'] +
                    '</li><li> αμέσως μικρότερη = ' + obj['idealPrevious'] + '' +
                    '</li><li> αμέσως μεγαλύτερη = ' + obj['idealNext'] + '</li></ul>';
                updateElementWithValue('content', value);

                document.forms["myForm"].elements["diameter"].value = obj['ideald'];

                confirmationModal.style.display = "block";

                // When the user clicks on (x), close the modal
                var span = document.getElementsByClassName("close")[0];
                span.onclick = function () {
                    closePopUp();
                }
            }
            else if (xmlhttp.status == 400) {
                alert('There was an error 400');
            }
            else {
                alert('Error returning response from server;');
            }
        }
    };

    xmlhttp.open("GET", host + "/rest/calculator/diameter?angle=" + angle + "&roughness=" + roughness + "&Qin=" +Qin +"&tin=" +tin +"&din=" +din, true);
    xmlhttp.send();
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    var confirmationModal = document.getElementById('confModal', 'btn', 'b1');
    if (event.target == confirmationModal) {
        confirmationModal.style.display = "none";
    }
}

function hideTable() {
    var resultsTable = document.getElementById("resultsTable");
    var button1 = document.getElementById("btn1");
    button1.style.display = "none";
    resultsTable.style.display = "none";
}

/**
 * makes a rest call to the back end in order to compute the required values,
 * and displays the response to results table.
 */

function computeAll(Qin, tin, angle, roughness, din) {
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == XMLHttpRequest.DONE) {
            if (xmlhttp.status == 200) {


                var obj = JSON.parse(xmlhttp.responseText);
                var resultsTable = document.getElementById("resultsTable");
                var button1 = document.getElementById("btn1");
                button1.style.display = "block";
                resultsTable.style.display = "block";


                // set the corresponding value to each cell of the table
                updateElementWithValue('angle', obj['angle']);
                updateElementWithValue('roughness', obj['roughness']);
                updateElementWithValue('tin', obj['tin']);
                updateElementWithValue('qin', obj['qin']);
                updateElementWithValue('idealt', obj['idealt']);
                updateElementWithValue('speed', obj['speed']);
                updateElementWithValue('surface', obj['surface']);
                updateElementWithValue('width', obj['width']);
                updateElementWithValue('energy', obj['energy']);
                updateElementWithValue('froud', obj['froud']);
            }
            else if (xmlhttp.status == 400) {
                alert('There was an error 400');
            }
            else {
                alert('something else other than 200 was returned');
            }
        }
    };

    var diameter = document.forms["myForm"].elements["diameter"].value;
    xmlhttp.open("GET", host + "/rest/calculator/allValues?Qin="
        + Qin + "&tin=" + tin + "&angle=" + angle + "&roughness=" + roughness + "&diameter=" + diameter, true);
    xmlhttp.send();
}
/**
 * validates that all required fields are filled.
 * If they are not it calls computeAll to compute the final results
 *  else it returns and shows a warning message next to the empty gields
 */

function validateAndComputeAll(Qin, tin, angle, roughness, din) {
    var isValid = true;

    var qinWarning = document.getElementsByClassName('qin-warning')[0];
    var dinWarning = document.getElementsByClassName('din-warning')[0];
    var tinWarning = document.getElementsByClassName('tin-warning')[0];

    if ((din.length == 0 && Qin.length == 0) && tin.length == 0) {
        dinWarning.style.display = 'block';
        qinWarning.style.display = 'block';
        tinWarning.style.display = 'block';
        var msg = 'Υποχρεωτικά πεδία είτε διάμετρος και παροχή αγωγού, είτε το βάθος'
        dinWarning.innerHTML = msg;
        qinWarning.innerHTML = msg;
        tinWarning.innerHTML = msg;
        isValid = false;
    } else if ((din.length != 0 && Qin.length == 0) || (din.length == 0 && Qin.length != 0)) {
        dinWarning.style.display = 'block';
        qinWarning.style.display = 'block';
        tinWarning.style.display = 'none';
        var msg = 'Υποχρεωτικά πεδία διάμετρος και παροχή αγωγού';
        dinWarning.innerHTML = msg;
        qinWarning.innerHTML = msg;
        isValid = false;
    } else {
        dinWarning.style.display = 'none';
        qinWarning.style.display = 'none';
        tinWarning.style.display = 'none';
    }

    var warning = document.getElementsByClassName('angle-warning')[0];
    if (angle.length == 0) {
        warning.style.display = 'block';
        isValid = false;
    } else {
        warning.style.display = 'none';
    }

    warning = document.getElementsByClassName('roughness-warning')[0];
    if (roughness.length == 0) {
        warning.style.display = 'block';
        isValid = false;
    } else {
        warning.style.display = 'none';
    }



    closePopUp();
    if (!isValid) {
        return;
    }

    computeAll(Qin, tin, angle, roughness, din);
}

/*--This JavaScript method for Print command--*/

function printDoc() {
    var toPrint = document.getElementById('resultsTable');
    var popupWin = window.open('', '_blank', 'width=1200,height=400,location=no,left=200px');
    popupWin.document.open();
    popupWin.document.write('<html><title>::Preview::</title><link rel="stylesheet" type="text/css" href="print.css" /></head><body onload="window.print()">')
    popupWin.document.write(toPrint.outerHTML);
    popupWin.document.write('</html>');
    popupWin.document.close();

}

